# PharmaGest Backend
Node.js + Express + PostgreSQL + OpenAI.

1. Installer Node.js 20+ et PostgreSQL 15+.
2. Créer la base `pharmagest`.
3. Exécuter `psql "$DATABASE_URL" -f sql/schema.sql`.
4. Copier `.env.example` vers `.env` et renseigner `DATABASE_URL`, `OPENAI_API_KEY`, `OPENAI_MODEL`, `CORS_ORIGIN`.
5. `npm install` puis `npm run dev`.
6. Tester `GET /api/health`.

Routes: `/api/medicaments`, `/api/dashboard`, `/api/ventes`, `/api/ai/chat`.
La clé OpenAI reste uniquement dans `.env` côté serveur et n'est jamais envoyée au navigateur.
