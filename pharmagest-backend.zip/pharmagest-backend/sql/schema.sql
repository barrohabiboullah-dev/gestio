CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS medicaments (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), nom TEXT NOT NULL, dci TEXT, categorie TEXT NOT NULL, prix NUMERIC(12,2) NOT NULL CHECK(prix>=0), quantite INTEGER NOT NULL DEFAULT 0 CHECK(quantite>=0), seuil INTEGER NOT NULL DEFAULT 0 CHECK(seuil>=0), expiration DATE, fournisseur TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS ventes (id BIGSERIAL PRIMARY KEY,total NUMERIC(12,2) NOT NULL CHECK(total>=0),created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS vente_articles (id BIGSERIAL PRIMARY KEY,vente_id BIGINT NOT NULL REFERENCES ventes(id) ON DELETE CASCADE,medicament_id UUID NOT NULL REFERENCES medicaments(id),quantite INTEGER NOT NULL CHECK(quantite>0),prix_unitaire NUMERIC(12,2) NOT NULL CHECK(prix_unitaire>=0));
CREATE TABLE IF NOT EXISTS mouvements_stock (id BIGSERIAL PRIMARY KEY,medicament_id UUID NOT NULL REFERENCES medicaments(id) ON DELETE CASCADE,type TEXT NOT NULL CHECK(type IN ('ENTREE','SORTIE','AJUSTEMENT')),quantite INTEGER NOT NULL CHECK(quantite>0),reference TEXT,created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS idx_medicaments_nom ON medicaments(nom);
CREATE INDEX IF NOT EXISTS idx_ventes_created_at ON ventes(created_at);
